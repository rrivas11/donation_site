<template>
<div>
  <section>
    <div id="nav">
    <h1> Donation site</h1>
    <router-link to="/list">My Donations </router-link>
    <router-link to="/form">Donate </router-link>
    <hr>
    </div>
    <router-view></router-view>
  </section>

</div>
</template>

<script>
export default {
    name: 'app',
    data () {
      return {
    }
  }
}
</script>

<style>

</style>
