import donationlist from './components/donationlist.vue';
import donationform from './components/donationform.vue';

export const routes = [
    {path: '/list',  component: donationlist},
    {path: '/form',  component: donationform},

];

