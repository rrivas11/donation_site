<template>
<div>

<div>
<form class="form-horizontal" @submit="formSubmit">
<fieldset>

<!-- Form Name -->
<div class="container">
    <div class="row">
      <div class="col-xs-12">
<h1 class="jumbotron">My Donations</h1>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="empresa">User</label>  
  <div class="col-md-4">
  <input id="empresa" name="user" type="text" placeholder="rrivas" v-model="newEntry.user" class="form-control input-md">
  </div>
</div>


<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="singlebutton"></label>
  <div class="col-md-4">
    <button class="btn btn-success btn-block">Search</button>
  </div>
</div>

</div>
</div>
</div>
</fieldset>
</form>
</div>


<div class="container">
    <div class="row">
      <div class="col-xs-12">
<table border="1" class="table table-stripped">
<thead>
	<th>Surnames</th>
	<th>Name</th>
	<th>Identification</th>
	<th>Country</th>
    <th>Institution</th>
	<th>Amount</th>
	<th>date</th>    
</thead>
<tbody>
	<tr v-for="data in donativeDetails.donations " v-bind:key="data.id">
		<td>{{data.Surnames}}</td>
		<td>{{data.Name}}</td>
		<td>{{data.id_document}}</td>
		<td>{{data.country}}</td>
        <td>{{data.institution}}</td>
        <td>{{data.donation_amount}}</td>
        <td>{{data.date}}</td>
	</tr>
 </tbody>
</table>
</div>
</div>
</div>

</div>
</template>

<script>
import axios from 'axios'; 

export default {
    mounted(){
        console.log('Component mounted.')
    },
      data(){
      return {
          output: '',
          donativeDetails : [
              {
                  Surnames:null,
                  Name: null,
                  id_document: null,
                  country: null,
                  institution: null,
                  donation_amount: null,
                  date: null
                }
            ],
          newEntry: {
            user: ''
        }
      }
   },
   methods: {
         formSubmit(e) {
                e.preventDefault();
                let currentObj = this;
                console.log(this.newEntry);
                axios.post('http://localhost:90/dnt/integrator/check-user-donative', this.newEntry, {
                })
                .then(response => {
                    this.donativeDetails = response.data;
                })
                .catch(function (error) {
                    currentObj.output = error;
                     console.log(error);
                });
            }
    }
  }
</script>

<style >
</style>