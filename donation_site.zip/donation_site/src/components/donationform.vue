<template>
 <div>

<div>
<form class="form-horizontal" @submit="formSubmit">
<fieldset>

<!-- Form Name -->
<div class="container">
    <div class="row">
      <div class="col-xs-12">
<h1 class="jumbotron">New Donative</h1>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="empresa">Usuario</label>  
  <div class="col-md-4">
  <input id="usuario" name="usuario" type="text" placeholder="rrivas" v-model="newEntry.user" class="form-control input-md">
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="titulo">Institution</label>  
  <div class="col-md-4">
  <input id="institution" name="institution" type="text" placeholder="ASALE" v-model="newEntry.institution_cod" class="form-control input-md">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="descuento">Mount</label>  
  <div class="col-md-4">
  <input id="mount" name="mount" type="number" placeholder="5.0" v-model="newEntry.mount" class="form-control input-md"> 
  </div>
</div>


<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="moneda">Credit card</label>  
  <div class="col-md-4">
  <input id="credit_card" name="credit_card" type="text" placeholder="4XXXXXXXXXXXXXXX" v-model="newEntry.credit_card" class="form-control input-md"> 
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="singlebutton"></label>
  <div class="col-md-4">
    <button class="btn btn-success">Submit</button>
  </div>
</div>
  <strong>Output:</strong>
    <pre>{{donationResponse}}</pre>
</div>
</div>
</div>
</fieldset>
</form>
</div>
</div>
</template>

<script>
import axios from 'axios';

export default {
    mounted() {
            console.log('Component mounted.')
        },
    data(){
        return {
            output: '',
            donationResponse: [],
            newEntry:{
                user: '',
                institution_cod: '',
                mount: 0.0,
                credit_card: ''
            }
        }
    },
    methods: {
            formSubmit(e) {
                e.preventDefault();
                let currentObj = this;
                console.log(this.newEntry);
                axios.post('http://localhost:90/dnt/integrator/donate', this.newEntry, {
                })
                .then(response => {
                    this.donationResponse = response.data;
                    currentObj.output = response.data;
                })
                .catch(function (error) {
                    currentObj.output = error;
                     console.log(error);
                });
            }
        }
}

</script>

<style>

</style>
